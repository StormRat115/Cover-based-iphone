# Isometric Cover Shooter Prototype

Open `index.html` in a mobile browser.

Controls:
- Tap the battlefield: move the armored soldier.
- Tap a bandit: select/lock that enemy.
- FIRE button: shoot the selected target, otherwise the nearest enemy.
- Gray barriers are cover. Standing behind/inside cover prevents the prototype's enemy shots.
- Restart resets the encounter.

This is a self-contained prototype using procedural canvas-drawn animated characters, so it needs no external assets or internet connection.
